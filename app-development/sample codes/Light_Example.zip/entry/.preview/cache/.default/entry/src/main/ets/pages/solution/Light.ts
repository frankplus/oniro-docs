interface LightPage_Params {
    isOn?: boolean;
}
class LightPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isOn = new ObservedPropertySimplePU(false, this, "isOn");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: LightPage_Params) {
        if (params.isOn !== undefined) {
            this.isOn = params.isOn;
        }
    }
    updateStateVars(params: LightPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isOn.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isOn.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isOn: ObservedPropertySimplePU<boolean>;
    get isOn() {
        return this.__isOn.get();
    }
    set isOn(newValue: boolean) {
        this.__isOn.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/solution/Light.ets(7:5)");
            Column.height('100%');
            Column.width('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isOn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create('pages/solution/images/img_light.png');
                        Image.debugLine("entry/src/main/ets/pages/solution/Light.ets(9:9)");
                        Image.height(300);
                        Image.width(300);
                        Image.borderRadius(20);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create('pages/solution/images/img_dark.png');
                        Image.debugLine("entry/src/main/ets/pages/solution/Light.ets(14:9)");
                        Image.height(300);
                        Image.width(300);
                        Image.borderRadius(20);
                    }, Image);
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 50 });
            Row.debugLine("entry/src/main/ets/pages/solution/Light.ets(19:7)");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('Turn Off');
            Button.debugLine("entry/src/main/ets/pages/solution/Light.ets(20:9)");
            Button.onClick(() => {
                this.isOn = false;
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('Turn On');
            Button.debugLine("entry/src/main/ets/pages/solution/Light.ets(24:9)");
            Button.onClick(() => {
                this.isOn = true;
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LightPage";
    }
}
registerNamedRoute(() => new LightPage(undefined, {}), "", { bundleName: "com.example.light_example", moduleName: "entry", pagePath: "pages/solution/Light" });
