export default class itemComponent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.appItem = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.appItem !== undefined) {
            this.appItem = params.appItem;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //自定义传参方法
    createIcon(icon, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(icon);
            Image.debugLine("pages/itemComponent.ets(9:5)");
            Image.width(20);
            Image.height(34);
            Image.margin(15);
            Image.objectFit(ImageFit.Contain);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
    }
    //layout
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            /**
             * In A ROW, the first element is icon, the second element is a taskText
             */
            Row.create();
            Row.debugLine("pages/itemComponent.ets(20:5)");
            /**
             * In A ROW, the first element is icon, the second element is a taskText
             */
            Row.borderRadius(24);
            /**
             * In A ROW, the first element is icon, the second element is a taskText
             */
            Row.backgroundColor(Color.White);
            /**
             * In A ROW, the first element is icon, the second element is a taskText
             */
            Row.width('100%');
            if (!isInitialRender) {
                /**
                 * In A ROW, the first element is icon, the second element is a taskText
                 */
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //1. Icon
        this.createIcon.bind(this)(this.appItem.logo);
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //2. Texts(Name + Desc)
            Column.create();
            Column.debugLine("pages/itemComponent.ets(24:7)");
            //2. Texts(Name + Desc)
            Column.alignItems(HorizontalAlign.Start);
            //2. Texts(Name + Desc)
            Column.width('50%');
            //2. Texts(Name + Desc)
            Column.justifyContent(FlexAlign.Start);
            if (!isInitialRender) {
                //2. Texts(Name + Desc)
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // Name
            Text.create(this.appItem.name);
            Text.debugLine("pages/itemComponent.ets(26:9)");
            // Name
            Text.fontSize(20);
            // Name
            Text.fontWeight(500);
            // Name
            Text.textOverflow({
                overflow: TextOverflow.Ellipsis
            });
            if (!isInitialRender) {
                // Name
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // Name
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //Desc
            Text.create(this.appItem.desc);
            Text.debugLine("pages/itemComponent.ets(34:14)");
            //Desc
            Text.textOverflow({
                overflow: TextOverflow.Ellipsis
            });
            if (!isInitialRender) {
                //Desc
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //Desc
        Text.pop();
        //2. Texts(Name + Desc)
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //3. Get Button
            Button.createWithLabel("Get", { type: ButtonType.Normal, stateEffect: true });
            Button.debugLine("pages/itemComponent.ets(46:7)");
            //3. Get Button
            Button.borderRadius(15);
            //3. Get Button
            Button.backgroundColor('#ff5786df');
            //3. Get Button
            Button.width(50);
            //3. Get Button
            Button.height(27);
            //3. Get Button
            Button.fontWeight(FontWeight.Bold);
            //3. Get Button
            Button.padding({ right: 0 });
            if (!isInitialRender) {
                //3. Get Button
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //3. Get Button
        Button.pop();
        /**
         * In A ROW, the first element is icon, the second element is a taskText
         */
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=itemComponent.js.map