export class DataModel {
    constructor() {
        this.tasks = [
            "Morning Exercise",
            "Prepare Breakfast",
            "Read Classics",
            "Study ArkTS",
            "Watch TV Series"
        ];
    }
    getData() {
        return this.tasks; // Return the 'tasks' array
    }
}
export default new DataModel(); // Export a new instance of the DataModel class
//# sourceMappingURL=DataModel.js.map