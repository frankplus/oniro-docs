export class AppInfo {
    constructor(id = 0, logo) {
        this.id = 0;
        this.id = id;
        this.logo = logo;
    }
}
export let AppInfo1 = new AppInfo(0, { "id": 16777224, "type": 20000, params: [], "bundleName": "com.example.task", "moduleName": "entry" });
AppInfo1.name = 'Element: Secure Messenger';
AppInfo1.desc = 'Encrypted chat for privacy and security.';
export let AppInfo2 = new AppInfo(1, { "id": 16777227, "type": 20000, params: [], "bundleName": "com.example.task", "moduleName": "entry" });
AppInfo2.name = 'PDF Reader: Viewer & Editor';
AppInfo2.desc = 'Read and annotate PDF documents on the go.';
export let AppInfo3 = new AppInfo(2, { "id": 16777223, "type": 20000, params: [], "bundleName": "com.example.task", "moduleName": "entry" });
AppInfo3.name = 'Signal: Private Messenger';
AppInfo3.desc = 'Privacy-focused chat app for secure communication.';
export let mockAppInfo = [AppInfo1, AppInfo2, AppInfo3];
//# sourceMappingURL=mockData.js.map