export class TestPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            RelativeContainer.create();
            RelativeContainer.debugLine("pages/TestPage.ets(6:5)");
            if (!isInitialRender) {
                RelativeContainer.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            __Common__.create();
            __Common__.alignRules({
                top: { anchor: '__container__', align: VerticalAlign.Top }
            });
            __Common__.margin({ left: 24, right: 24, top: 42 });
            __Common__.id('printer_info_layout');
            if (!isInitialRender) {
                __Common__.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new NameLayout(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        __Common__.pop();
        RelativeContainer.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class NameLayout extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            RelativeContainer.create();
            RelativeContainer.debugLine("pages/TestPage.ets(22:5)");
            RelativeContainer.width('100%');
            RelativeContainer.height(354);
            if (!isInitialRender) {
                RelativeContainer.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //打印机信息布局layout
            Column.create();
            Column.debugLine("pages/TestPage.ets(24:7)");
            //打印机信息布局layout
            Column.alignRules({
                bottom: { anchor: '__container__', align: VerticalAlign.Bottom }
            });
            //打印机信息布局layout
            Column.linearGradient({
                angle: 180,
                colors: [[$r('app.color.99_white'), 0.0], [$r('app.color.white'), 1.0]]
            });
            //打印机信息布局layout
            Column.border({ radius: 20 });
            //打印机信息布局layout
            Column.width('100%');
            //打印机信息布局layout
            Column.height(216);
            //打印机信息布局layout
            Column.id('printer_info_layout');
            if (!isInitialRender) {
                //打印机信息布局layout
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            RelativeContainer.create();
            RelativeContainer.debugLine("pages/TestPage.ets(25:9)");
            RelativeContainer.width('100%');
            RelativeContainer.height(75);
            if (!isInitialRender) {
                RelativeContainer.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('M6700DW-ABCDEFGHIJKLMNOP');
            Text.debugLine("pages/TestPage.ets(26:11)");
            Text.fontColor($r('app.color.color_FF333333'));
            Text.fontSize(27);
            Text.fontWeight(500);
            Text.lineHeight(39);
            Text.textAlign(TextAlign.Start);
            Text.textOverflow({
                overflow: TextOverflow.Ellipsis
            });
            Text.maxLines(1);
            Text.backgroundColor('#95095cec');
            Text.alignRules({
                top: { anchor: '__container__', align: VerticalAlign.Top },
                left: { anchor: '__container__', align: HorizontalAlign.Start }
            });
            Text.margin({
                top: 36,
                left: 24,
                right: 6
            });
            Text.constraintSize({
                minWidth: 0,
                maxWidth: 417
            });
            Text.id('printer_model_type_name_text');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['svg/svg_icon_right_arrow.svg'], "bundleName": "com.example.task", "moduleName": "entry" });
            Image.debugLine("pages/TestPage.ets(52:11)");
            Image.width(36);
            Image.height(36);
            Image.alignRules({
                top: { anchor: 'printer_model_type_name_text', align: VerticalAlign.Top },
                bottom: { anchor: 'printer_model_type_name_text', align: VerticalAlign.Bottom },
                left: { anchor: 'printer_model_type_name_text', align: HorizontalAlign.End }
            });
            Image.margin({
                top: 36,
            });
            Image.id('printer_model_type_name_arrow');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        RelativeContainer.pop();
        //打印机信息布局layout
        Column.pop();
        RelativeContainer.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "NameLayout", new NameLayout(undefined, {}));
    ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
    loadDocument(new TestPage(undefined, {}));
    ViewStackProcessor.StopGetAccessRecording();
}
//# sourceMappingURL=TestPage.js.map