export default class ToDoItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.content = undefined;
        this.__isComplete = new ObservedPropertySimplePU(false, this, "isComplete");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.content !== undefined) {
            this.content = params.content;
        }
        if (params.isComplete !== undefined) {
            this.isComplete = params.isComplete;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isComplete.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isComplete.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get isComplete() {
        return this.__isComplete.get();
    }
    set isComplete(newValue) {
        this.__isComplete.set(newValue);
    }
    labelIcon(icon, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(icon);
            Image.debugLine("pages/ToDoItem.ets(7:5)");
            Image.objectFit(ImageFit.Contain);
            Image.width("28vp");
            Image.height("28vp");
            Image.margin("20vp");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
    }
    //create a folder (here 'images') under the 'ets' path to store the pictures
    // use the Image component and the local path to import the picture
    // Example : Image('images/view.jpg')
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/ToDoItem.ets(18:5)");
            Row.borderRadius(24);
            Row.backgroundColor("#FFFFFF");
            Row.width('93.3%');
            Row.height("64vp");
            Row.onClick(() => {
                this.isComplete = !this.isComplete; // Toggle the 'isComplete' state on click
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.isComplete) { // If the task is complete
                this.ifElseBranchUpdateFunction(0, () => {
                    this.labelIcon.bind(this)('images/ic_ok.png');
                });
            }
            else { // Otherwise
                this.ifElseBranchUpdateFunction(1, () => {
                    this.labelIcon.bind(this)('images/ic_default.png');
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.content);
            Text.debugLine("pages/ToDoItem.ets(26:7)");
            Text.fontSize("20fp");
            Text.fontWeight(500);
            Text.opacity(this.isComplete ? 0.4 : 1);
            Text.decoration({ type: this.isComplete ? TextDecorationType.LineThrough : TextDecorationType.None });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=ToDoItem.js.map