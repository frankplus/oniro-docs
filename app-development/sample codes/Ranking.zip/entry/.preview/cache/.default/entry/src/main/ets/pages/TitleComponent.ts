interface TitleComponent_Params {
    isRefreshData?: boolean;
    title?: string;
}
import type AppContext from "@ohos:app.ability.common";
export class TitleComponent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isRefreshData = new SynchedPropertySimpleTwoWayPU(params.isRefreshData, this, "isRefreshData");
        this.__title = new ObservedPropertySimplePU("", this, "title");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: TitleComponent_Params) {
        if (params.title !== undefined) {
            this.title = params.title;
        }
    }
    updateStateVars(params: TitleComponent_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isRefreshData.purgeDependencyOnElmtId(rmElmtId);
        this.__title.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isRefreshData.aboutToBeDeleted();
        this.__title.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isRefreshData: SynchedPropertySimpleTwoWayPU<boolean>; // Controls whether data should refresh
    get isRefreshData() {
        return this.__isRefreshData.get();
    }
    set isRefreshData(newValue: boolean) {
        this.__isRefreshData.set(newValue);
    }
    private __title: ObservedPropertySimplePU<string>; // Title of the page
    get title() {
        return this.__title.get();
    }
    set title(newValue: string) {
        this.__title.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/TitleComponent.ets(9:5)");
            Row.width('100%');
            Row.padding({ left: 26, right: 26 });
            Row.margin({ top: 10 });
            Row.height(47);
            Row.justifyContent(FlexAlign.SpaceAround);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/TitleComponent.ets(10:7)");
            Row.width('50%');
            Row.height('100%');
            Row.justifyContent(FlexAlign.Start);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create('images/back.png');
            Image.debugLine("entry/src/main/ets/pages/TitleComponent.ets(11:9)");
            Image.height(21);
            Image.width(21);
            Image.margin({ right: 18 });
            Image.onClick(() => {
                let handler = getContext(this) as AppContext.UIAbilityContext;
                handler.terminateSelf(); // Ends the current page
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.title);
            Text.debugLine("entry/src/main/ets/pages/TitleComponent.ets(20:9)");
            Text.fontSize(20);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/TitleComponent.ets(27:7)");
            Row.width('50%');
            Row.height('100%');
            Row.justifyContent(FlexAlign.End);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create('images/loading.png');
            Image.debugLine("entry/src/main/ets/pages/TitleComponent.ets(28:9)");
            Image.height(22);
            Image.width(22);
            Image.onClick(() => {
                this.isRefreshData = !this.isRefreshData; // Toggles data refresh
            });
        }, Image);
        Row.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
