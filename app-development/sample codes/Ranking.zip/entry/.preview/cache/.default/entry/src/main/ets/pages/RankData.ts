// RankData class - Language object
export class RankData {
    name: string; // Language name
    marketShare: string; // Market share percentage
    id: string; // Unique identifier
    constructor(id: string, name: string, marketShare: string) {
        this.id = id;
        this.name = name;
        this.marketShare = marketShare;
    }
}
