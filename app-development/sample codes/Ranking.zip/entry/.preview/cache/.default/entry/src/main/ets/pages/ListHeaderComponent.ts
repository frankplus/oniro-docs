interface ListHeaderComponent_Params {
    paddingValue?: Padding | Length;
    widthValue?: Length;
}
export class ListHeaderComponent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.paddingValue = 0;
        this.widthValue = 0;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: ListHeaderComponent_Params) {
        if (params.paddingValue !== undefined) {
            this.paddingValue = params.paddingValue;
        }
        if (params.widthValue !== undefined) {
            this.widthValue = params.widthValue;
        }
    }
    updateStateVars(params: ListHeaderComponent_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private paddingValue: Padding | Length;
    private widthValue: Length;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ListHeaderComponent.ets(7:5)");
            Row.width(this.widthValue);
            Row.padding(this.paddingValue);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Rank');
            Text.debugLine("entry/src/main/ets/pages/ListHeaderComponent.ets(8:7)");
            Text.fontSize(14);
            Text.width('30%');
            Text.fontWeight(400);
            Text.fontColor('#989A9C');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Language');
            Text.debugLine("entry/src/main/ets/pages/ListHeaderComponent.ets(14:7)");
            Text.fontSize(14);
            Text.width('50%');
            Text.fontWeight(400);
            Text.fontColor('#989A9C');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Market Share');
            Text.debugLine("entry/src/main/ets/pages/ListHeaderComponent.ets(20:7)");
            Text.fontSize(14);
            Text.width('20%');
            Text.fontWeight(400);
            Text.fontColor('#989A9C');
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
