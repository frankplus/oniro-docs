interface RankPage_Params {
    dataSource1?: RankData[];
    dataSource2?: RankData[];
    isSwitchDataSource?: boolean;
}
import { ListHeaderComponent } from "@bundle:com.example.ranking/entry/ets/pages/ListHeaderComponent";
import { ListItemComponent } from "@bundle:com.example.ranking/entry/ets/pages/ListItemComponent";
import { RankData } from "@bundle:com.example.ranking/entry/ets/pages/RankData";
import { TitleComponent } from "@bundle:com.example.ranking/entry/ets/pages/TitleComponent";
class RankPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__dataSource1 = new ObservedPropertyObjectPU([
            new RankData('1', 'Python', '28.11%'),
            new RankData('2', 'Java', '15.52%'),
            new RankData('3', 'JavaScript', '8.57%'),
            new RankData('4', 'C/C++', '6.92%'),
            new RankData('5', 'C#', '6.73%'),
            new RankData('6', 'R', '4.75%'),
            new RankData('7', 'PHP', '4.57%'),
            new RankData('8', 'TypeScript', '2.78%'),
            new RankData('9', 'Swift', '2.75%'),
            new RankData('10', 'Objective-C', '2.37%')
        ], this, "dataSource1");
        this.__dataSource2 = new ObservedPropertyObjectPU([ /* Additional data source */], this, "dataSource2");
        this.__isSwitchDataSource = new ObservedPropertySimplePU(true, this, "isSwitchDataSource");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: RankPage_Params) {
        if (params.dataSource1 !== undefined) {
            this.dataSource1 = params.dataSource1;
        }
        if (params.dataSource2 !== undefined) {
            this.dataSource2 = params.dataSource2;
        }
        if (params.isSwitchDataSource !== undefined) {
            this.isSwitchDataSource = params.isSwitchDataSource;
        }
    }
    updateStateVars(params: RankPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__dataSource1.purgeDependencyOnElmtId(rmElmtId);
        this.__dataSource2.purgeDependencyOnElmtId(rmElmtId);
        this.__isSwitchDataSource.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__dataSource1.aboutToBeDeleted();
        this.__dataSource2.aboutToBeDeleted();
        this.__isSwitchDataSource.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __dataSource1: ObservedPropertyObjectPU<RankData[]>;
    get dataSource1() {
        return this.__dataSource1.get();
    }
    set dataSource1(newValue: RankData[]) {
        this.__dataSource1.set(newValue);
    }
    private __dataSource2: ObservedPropertyObjectPU<RankData[]>;
    get dataSource2() {
        return this.__dataSource2.get();
    }
    set dataSource2(newValue: RankData[]) {
        this.__dataSource2.set(newValue);
    }
    private __isSwitchDataSource: ObservedPropertySimplePU<boolean>;
    get isSwitchDataSource() {
        return this.__isSwitchDataSource.get();
    }
    set isSwitchDataSource(newValue: boolean) {
        this.__isSwitchDataSource.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RankPage.ets(26:5)");
            Column.backgroundColor("#F1F3F5");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new TitleComponent(this, { isRefreshData: this.__isSwitchDataSource, title: "Programming Language Rankings" }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RankPage.ets", line: 27 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            isRefreshData: this.isSwitchDataSource,
                            title: "Programming Language Rankings"
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "TitleComponent" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.margin({ top: 20, bottom: 15 });
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new ListHeaderComponent(this, {
                        paddingValue: { left: 15, right: 15 },
                        widthValue: '90%'
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RankPage.ets", line: 29 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            paddingValue: { left: 15, right: 15 },
                            widthValue: '90%'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "ListHeaderComponent" });
        }
        __Common__.pop();
        this.RankList.bind(this)('90%');
        Column.pop();
    }
    RankList(widthValue: Length, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RankPage.ets(43:5)");
            Column.padding({ left: 15, right: 15 });
            Column.borderRadius(20);
            Column.width(widthValue);
            Column.alignItems(HorizontalAlign.Center);
            Column.backgroundColor(Color.White);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/pages/RankPage.ets(44:7)");
            List.width('100%');
            List.height('65%');
            List.divider({ strokeWidth: 1 });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index?: number) => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/RankPage.ets(46:11)");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new ListItemComponent(this, {
                                        index: (Number(index) + 1),
                                        name: item.name,
                                        marketShare: item.marketShare,
                                        isSwitchDataSource: this.isSwitchDataSource
                                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/RankPage.ets", line: 47 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            index: (Number(index) + 1),
                                            name: item.name,
                                            marketShare: item.marketShare,
                                            isSwitchDataSource: this.isSwitchDataSource
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                            }, { name: "ListItemComponent" });
                        }
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.isSwitchDataSource ? this.dataSource1 : this.dataSource2, forEachItemGenFunction, (item: RankData) => JSON.stringify(item), true, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "RankPage";
    }
}
registerNamedRoute(() => new RankPage(undefined, {}), "", { bundleName: "com.example.ranking", moduleName: "entry", pagePath: "pages/RankPage" });
