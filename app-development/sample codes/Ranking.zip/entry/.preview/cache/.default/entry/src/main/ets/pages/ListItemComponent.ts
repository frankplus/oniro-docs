interface ListItemComponent_Params {
    index?: number;
    name?: string;
    marketShare?: string;
    isSwitchDataSource?: boolean;
    isChange?: boolean;
}
export class ListItemComponent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.index = undefined;
        this.name = undefined;
        this.marketShare = '';
        this.isSwitchDataSource = false;
        this.__isChange = new ObservedPropertySimplePU(false, this, "isChange");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: ListItemComponent_Params) {
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.name !== undefined) {
            this.name = params.name;
        }
        if (params.marketShare !== undefined) {
            this.marketShare = params.marketShare;
        }
        if (params.isSwitchDataSource !== undefined) {
            this.isSwitchDataSource = params.isSwitchDataSource;
        }
        if (params.isChange !== undefined) {
            this.isChange = params.isChange;
        }
    }
    updateStateVars(params: ListItemComponent_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isChange.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isChange.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private index?: number; // Item index
    private name?: string; // Language name
    private marketShare: string; // Market share percentage
    private isSwitchDataSource: boolean; // Toggle data source flag
    private __isChange: ObservedPropertySimplePU<boolean>; // Triggers UI refresh on change
    get isChange() {
        return this.__isChange.get();
    }
    set isChange(newValue: boolean) {
        this.__isChange.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ListItemComponent.ets(11:5)");
            Row.height(48);
            Row.width('100%');
            Row.onClick(() => {
                this.isSwitchDataSource = !this.isSwitchDataSource;
                this.isChange = !this.isChange;
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ListItemComponent.ets(12:7)");
            Column.width('30%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isRenderCircleText()) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.index !== undefined) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.CircleText.bind(this)(this.index);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.index?.toString());
                        Text.debugLine("entry/src/main/ets/pages/ListItemComponent.ets(18:11)");
                        Text.lineHeight(24);
                        Text.textAlign(TextAlign.Center);
                        Text.width(24);
                        Text.fontWeight('400');
                        Text.fontSize(14);
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.name);
            Text.debugLine("entry/src/main/ets/pages/ListItemComponent.ets(29:7)");
            Text.width('50%');
            Text.fontWeight('500');
            Text.fontSize(16);
            Text.fontColor(this.isChange ? "#007DFF" : "#182431");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.marketShare);
            Text.debugLine("entry/src/main/ets/pages/ListItemComponent.ets(35:7)");
            Text.width('20%');
            Text.fontWeight('400');
            Text.fontSize(14);
            Text.fontColor(this.isChange ? "#007DFF" : "#182431");
        }, Text);
        Text.pop();
        Row.pop();
    }
    CircleText(index: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ListItemComponent.ets(50:5)");
            Row.justifyContent(FlexAlign.Center);
            Row.borderRadius(24);
            Row.size({ width: 24, height: 24 });
            Row.backgroundColor("#007dff");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.index?.toString());
            Text.debugLine("entry/src/main/ets/pages/ListItemComponent.ets(51:7)");
            Text.fontWeight('400');
            Text.fontSize(14);
            Text.fontColor(Color.White);
        }, Text);
        Text.pop();
        Row.pop();
    }
    isRenderCircleText(): boolean {
        return this.index === 1 || this.index === 2 || this.index === 3;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
