# OHScrcpy

> 软件作者：https://kaihongpai.feishu.cn/wiki/CqWLwJRadibxztkrIWZcogWxnXd  
> 哔哩哔哩：https://space.bilibili.com/74433635  
> 更新发布：https://www.bilibili.com/read/cv24125018  

## 软件说明

- 一款OpenHarmony（3.2+）设备的投屏工具，只是名字类似安卓的投屏工具Scrcpy，开发技术和实现方式完全不同。
- 目前仅初步实现，距离低延迟、高帧率、手势交互的实现，还有很长的路要走...

## 更新说明

### OHScrcpy 1.0 Beta4 (2024-04-01)

- 适配API11的设备，并初步支持模拟输入文本（API11+）
- 右键菜单 - 更多操作，新增挂载系统可写、设备屏幕常亮等实用功能
- 重新设计关于页面

### OHScrcpy 1.0 Beta3 (2023-08-28)

- 初步支持键盘控制，暂不支持组合键（ESC键=设备返回键）
- F3亮屏字样改为解锁，按下等于亮屏+滑动解锁

### OHScrcpy 1.0 Beta2 (2023-07-04)

- 提高投屏窗口显示比例精确度
- 支持点触投屏窗口控制设备（滑动手势、长按等操作暂未实现）
- “双击任意区域”以自动调整窗口更改为“双击多余黑色边框处”

### OHScrcpy 1.0 Beta1 (2023-06-04)

- 初步实现
